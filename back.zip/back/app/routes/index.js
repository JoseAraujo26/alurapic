const commentRoutes = require('./comment')
    ,photoRoutes = require('./photo')
    , userRoutes = require('./user');

module.exports = { commentRoutes, photoRoutes, userRoutes };